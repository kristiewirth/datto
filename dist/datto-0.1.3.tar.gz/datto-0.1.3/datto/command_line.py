import os

def main():
    os.system('python -m spacy download en')