# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['datto']

package_data = \
{'': ['*'], 'datto': ['data/*']}

install_requires = \
['black>=19.10b0,<20.0',
 'ipython>=7.8,<8.0',
 'notebook>=6.0.3,<7.0.0',
 'pandas>=1.0.4,<2.0.0',
 'pylint>=2.5.0,<3.0.0',
 'pytest>=5.2,<6.0',
 'spacy>=2.2.4,<3.0.0']

entry_points = \
{'console_scripts': ['install-spacy-en = datto.command_line:main']}

setup_kwargs = {
    'name': 'datto',
    'version': '0.1.4',
    'description': 'Data Tools (Dat To)',
    'long_description': None,
    'author': 'kristiewirth',
    'author_email': 'kristie.ann.wirth@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
